function myMap(){
    var mapOptions ={
        center: new google.maps.LatLng(21.0277644, 105.83415979999995),
        
        zoom: 21,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map=new google.maps.Map(document.getElementById("map"),mapOptions);
    var myButton=document.querySelector('button');
    myButton.onclick=function()
    {
        var latitude=prompt("Latitude");
        var longtitude=prompt("Longtitude");
        var discription=prompt("Discription");
        var data=prompt("Data");
    
        let myLaLng=new google.maps.LatLng(latitude,longtitude);
        var maker=new google.maps.Maker(
            {
                position:myLaLng,
                map:map,
                Discrip: discription,
                Data: data
            }
        )

    }
    var staticMapUrl="https://maps.googleapis.com/maps/api/staticmap";
    staticMapUrl+="?center="+latitude+","+longtitude+"&size=220x350"+"&zoom="+mapOptions.zoom+"&maptype="+mapOptions.mapTypeId;
    staticMapUrl+="&markers=color:red|" + latitude+","+longtitude;
    var imgMap=document.getElementById("imgMap");
    imgMap.src=staticMapUrl;
    imgMap.style.display="block";
    

}


